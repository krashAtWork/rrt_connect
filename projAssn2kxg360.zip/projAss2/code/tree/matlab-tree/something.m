lineage = tree.example;
disp(lineage.tostring)